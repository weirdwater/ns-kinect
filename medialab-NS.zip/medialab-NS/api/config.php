<?php
	define("DB_HOST", "localhost");
	define("DB_NAME", "prj_2016_2017_medialab_ns_t3");
	define("DB_USERNAME", "root");
	define("DB_PASSWORD", "");

	header('Content-Type: application/json');
?>